# BKG Geocoder

QGIS plugin for geocoding addresses with the geocoding API of the Bundesamt für Kartographie und Geodäsie (https://gdz.bkg.bund.de/).
